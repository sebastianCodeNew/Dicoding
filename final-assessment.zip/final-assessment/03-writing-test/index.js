function sum(a, b) {
  return a + b;
}

export { sum };
